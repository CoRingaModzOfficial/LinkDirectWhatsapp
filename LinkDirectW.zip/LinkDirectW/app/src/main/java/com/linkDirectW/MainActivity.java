package com.linkDirectW;


import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import java.text.*;
import android.app.Activity;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.widget.AdapterView;
import android.content.ClipData;
import android.content.ClipboardManager;

public class MainActivity extends Activity {


	private ArrayList<String> spinner = new ArrayList<>();

	private LinearLayout linear1;
	private LinearLayout linear2;
	private EditText edittext2;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private EditText edittext1;
	private Button button1;
	private TextView textview1;
	private Spinner spinner1;

	private AlertDialog.Builder popupd;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.activity_main);
		initialize(_savedInstanceState);
		initializeLogic();
	}

	private void initialize(Bundle _savedInstanceState) {

		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		button1 = (Button) findViewById(R.id.button1);
		textview1 = (TextView) findViewById(R.id.textview1);
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		popupd = new AlertDialog.Builder(this);

		button1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (edittext2.getText().toString().contains(edittext2.getText().toString())) {
						edittext2.setText(edittext2.getText().toString().replace("CORINGA", edittext1.getText().toString()));
						popupd.setTitle("Link Direct Criador Sucess!!");
						popupd.setMessage("Seu Link :".concat(edittext2.getText().toString()));
						popupd.setPositiveButton("COPY", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface _dialog, int _which) {
									((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", edittext2.getText().toString()));
									Toast.makeText(getApplicationContext(), "Copiado!", Toast.LENGTH_SHORT).show();
								}
							});
						popupd.create().show();
					}
					else {
						Toast.makeText(getApplicationContext(), "SO PODE USAR UMA VEZ POR EXECULÇÃO!", Toast.LENGTH_SHORT).show();
					}
				}
			});

		spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
				@Override
				public void onItemSelected(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
					final int _position = _param3;
					if (_position == 0) {

					}
					if (_position == 1) {
						if (edittext2.getText().toString().contains(edittext2.getText().toString())) {
							edittext2.setText(edittext2.getText().toString().replace("+55", "+55"));
							Toast.makeText(getApplicationContext(), "Brasil", Toast.LENGTH_SHORT).show();
						}
					}
					if (_position == 2) {
						if (edittext2.getText().toString().contains(edittext2.getText().toString())) {
							edittext2.setText(edittext2.getText().toString().replace("+55", "+62"));
							Toast.makeText(getApplicationContext(), "Indonésia", Toast.LENGTH_SHORT).show();
						}
					}
					if (_position == 3) {
						if (edittext2.getText().toString().contains(edittext2.getText().toString())) {
							edittext2.setText(edittext2.getText().toString().replace("+55", "+1"));
							Toast.makeText(getApplicationContext(), "Estados Unidos", Toast.LENGTH_SHORT).show();
						}
					}
				}

				@Override
				public void onNothingSelected(AdapterView<?> _param1) {

				}
			});
	}
	private void initializeLogic() {
		spinner.add("DDI dos pais:");
		spinner.add("Brasil BR/+55");
		spinner.add("Indonésia ID/+62");
		spinner.add("Estados Unidos (EUA) US/+1");
		spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, spinner));
		if ("Copyright ©CoRinga Modz".equals("Copyright ©CoRinga Modz")) {

		}
		else {
			Toast.makeText(getApplicationContext(), "Você Editou Uma Coisa Sem Permissões!!\n\nCoRinga Protector !!", Toast.LENGTH_SHORT).show();
			finish();
		}
	}
}
